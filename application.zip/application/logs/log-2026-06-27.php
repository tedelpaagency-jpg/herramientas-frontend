<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-27 01:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-27 06:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-27 07:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-27 11:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-27 20:01:35 --> 404 Page Not Found: Robotstxt/index
