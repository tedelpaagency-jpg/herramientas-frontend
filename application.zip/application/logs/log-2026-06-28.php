<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-28 07:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-28 11:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-28 13:19:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2026-06-28 13:19:11 --> 404 Page Not Found: App-adstxt/index
ERROR - 2026-06-28 13:19:11 --> 404 Page Not Found: Sellersjson/index
ERROR - 2026-06-28 14:11:39 --> 404 Page Not Found: Config/index
ERROR - 2026-06-28 14:11:41 --> 404 Page Not Found: Env/index
ERROR - 2026-06-28 14:11:43 --> 404 Page Not Found: Envlocal/index
ERROR - 2026-06-28 14:11:46 --> 404 Page Not Found: Envlocal/index
ERROR - 2026-06-28 15:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-28 15:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-28 16:14:34 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-28 20:31:53 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2026-06-28 21:45:32 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2026-06-28 22:10:55 --> 404 Page Not Found: Components/com_jce
ERROR - 2026-06-28 23:11:35 --> 404 Page Not Found: Robotstxt/index
