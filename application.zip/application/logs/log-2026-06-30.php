<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-06-30 00:09:23 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2026-06-30 12:33:26 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-30 12:33:36 --> 404 Page Not Found: Portal/whatsapptest
ERROR - 2026-06-30 12:34:02 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 49
ERROR - 2026-06-30 12:34:02 --> cURL Error: 
ERROR - 2026-06-30 12:34:02 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:34:02 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:34:02 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:35:41 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 49
ERROR - 2026-06-30 12:35:41 --> cURL Error: 
ERROR - 2026-06-30 12:35:41 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:35:41 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:35:41 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:36:01 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 49
ERROR - 2026-06-30 12:36:01 --> cURL Error: 
ERROR - 2026-06-30 12:36:01 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:36:01 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:36:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:38:11 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 49
ERROR - 2026-06-30 12:38:11 --> cURL Error: 
ERROR - 2026-06-30 12:38:11 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:38:11 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:38:11 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 54
ERROR - 2026-06-30 12:49:34 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 49
ERROR - 2026-06-30 12:49:34 --> cURL Error: 
ERROR - 2026-06-30 12:50:23 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 50
ERROR - 2026-06-30 12:50:23 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:50:23 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:50:23 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:50:53 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 50
ERROR - 2026-06-30 12:50:53 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:50:53 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:50:53 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:51:17 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 50
ERROR - 2026-06-30 12:51:17 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:51:17 --> Severity: Warning --> Undefined array key "response" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:51:17 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 55
ERROR - 2026-06-30 12:51:47 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 50
ERROR - 2026-06-30 12:56:53 --> Severity: Warning --> Undefined array key "status" /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 64
ERROR - 2026-06-30 12:57:10 --> Severity: Warning --> Array to string conversion /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 64
ERROR - 2026-06-30 14:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-30 16:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-30 22:03:43 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 203
ERROR - 2026-06-30 22:03:43 --> cURL Error: Could not resolve host: ws.nuovo.pro
ERROR - 2026-06-30 22:03:43 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:03:43 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:03:43 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:03:43 --> Severity: Warning --> Array to string conversion /home/u904440099/domains/recetarfacil.com/public_html/application/controllers/Portal.php 3926
ERROR - 2026-06-30 22:04:16 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 203
ERROR - 2026-06-30 22:04:16 --> cURL Error: Could not resolve host: ws.nuovo.pro
ERROR - 2026-06-30 22:04:16 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:04:16 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:04:16 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Whatsapp_model.php 208
ERROR - 2026-06-30 22:04:55 --> cURL Error: 
ERROR - 2026-06-30 22:05:15 --> {"key":{"remoteJid":"50247358248@s.whatsapp.net","fromMe":true,"id":"3EB011E17EA7C30522A0AA"},"pushName":"Você","status":"PENDING","message":{"conversation":"Api funcionando"},"contextInfo":{"mentionedJid":[],"groupMentions":[],"ephemeralSettingTimestamp":{"low":1782702315,"high":0,"unsigned":false},"disappearingMode":{"initiator":0}},"messageType":"conversation","messageTimestamp":1782875115,"instanceId":"be03ceb0-9323-4008-9915-4502ebd51ede","source":"web"}
