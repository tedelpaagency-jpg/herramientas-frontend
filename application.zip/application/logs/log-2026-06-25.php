ERROR - 2026-06-25 23:04:13 --> Severity: Warning --> Attempt to read property "user_id" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_form.php 90
ERROR - 2026-06-25 23:04:13 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-06-25 23:04:13 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-06-25 23:04:13 --> 404 Page Not Found: Public/assets
ERROR - 2026-06-25 23:04:27 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:04:33 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:06:33 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:08:00 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:08:44 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:09:35 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:10:17 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:11:06 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-06-25 23:46:01 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:03 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:04 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:05 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:08 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:09 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-06-25 23:46:10 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
