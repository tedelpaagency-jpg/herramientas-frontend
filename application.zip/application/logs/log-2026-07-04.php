<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-04 00:11:54 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2026-07-04 02:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-04 06:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-04 07:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-04 10:26:44 --> 404 Page Not Found: Apple-touch-iconpng/index
