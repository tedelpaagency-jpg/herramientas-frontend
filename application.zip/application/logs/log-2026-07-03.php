<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-07-03 02:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-03 04:24:32 --> 404 Page Not Found: Plesk-stat/index
ERROR - 2026-07-03 07:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-03 13:03:29 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 13:04:02 --> Severity: Warning --> Attempt to read property "nombre" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_profile.php 197
ERROR - 2026-07-03 15:09:53 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 15:26:17 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 15:26:52 --> Severity: Warning --> Undefined array key "description" /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/partials/modals/ajax_recipe.php 78
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "last_name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "phone" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined property: stdClass::$age /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "last_name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined variable $patient /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Attempt to read property "phone" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:26:54 --> Severity: Warning --> Undefined property: stdClass::$age /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:27:28 --> {"patient_id":42744,"patient_name":"Angel  Tezo","phone":"123456789","age":"30 a\u00f1os","medications":[{"id":"1529","n":"PARASINOX 100MG SUSP *60ML","d":"1"}],"labs":[],"comment":"","next_appointment":""}
ERROR - 2026-07-03 15:27:28 --> Severity: Warning --> Undefined array key "consultation_id" /home/u904440099/domains/recetarfacil.com/public_html/application/controllers/Prescriptions.php 68
ERROR - 2026-07-03 15:27:40 --> {"patient_id":42744,"patient_name":"Angel  Tezo","phone":"123456789","age":"30 a\u00f1os","medications":[{"id":"1529","n":"PARASINOX 100MG SUSP *60ML","d":"1"}],"labs":[],"comment":"","next_appointment":""}
ERROR - 2026-07-03 15:27:40 --> Severity: Warning --> Undefined array key "consultation_id" /home/u904440099/domains/recetarfacil.com/public_html/application/controllers/Prescriptions.php 68
ERROR - 2026-07-03 15:27:47 --> Severity: Warning --> Attempt to read property "name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:27:47 --> Severity: Warning --> Attempt to read property "last_name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 104
ERROR - 2026-07-03 15:27:47 --> Severity: Warning --> Attempt to read property "phone" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:27:47 --> Severity: Warning --> Undefined property: stdClass::$age /home/u904440099/domains/recetarfacil.com/public_html/application/views/pdf/prescription.php 106
ERROR - 2026-07-03 15:27:48 --> id de receta https://recetarfacil.com/uploads/temp/receta_7_1783110468.pdf
ERROR - 2026-07-03 15:27:48 --> Severity: Warning --> Attempt to read property "phone" on null /home/u904440099/domains/recetarfacil.com/public_html/application/controllers/Prescriptions.php 303
ERROR - 2026-07-03 15:27:49 --> cURL Error: {"status":400,"error":"Bad Request","response":{"message":[{"jid":"@s.whatsapp.net","exists":false,"number":""}]}}
ERROR - 2026-07-03 15:28:11 --> Severity: Warning --> Attempt to read property "nombre" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_profile.php 194
ERROR - 2026-07-03 15:28:21 --> Severity: Warning --> Attempt to read property "nombre" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_profile.php 194
ERROR - 2026-07-03 15:28:28 --> Severity: Warning --> Attempt to read property "nombre" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_profile.php 194
ERROR - 2026-07-03 15:35:50 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Undefined variable $rol_id /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/agencies.php 19
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Attempt to read property "name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/agencies.php 19
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 15:36:47 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 17:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2026-07-03 20:31:57 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 20:32:15 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 20:32:20 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Undefined variable $rol_id /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/agencies.php 19
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Attempt to read property "name" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/agencies.php 19
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 72
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 34
ERROR - 2026-07-03 20:33:01 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:40:58 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:41:17 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:41:17 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:41:18 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:41:18 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:41:19 --> 404 Page Not Found: Public/assets
ERROR - 2026-07-03 21:41:24 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:42:39 --> Severity: Warning --> Undefined property: stdClass::$system_name /home/u904440099/domains/recetarfacil.com/public_html/application/models/Crud_model.php 21
ERROR - 2026-07-03 21:42:39 --> Severity: Warning --> Undefined property: stdClass::$iframes /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/settings.php 279
ERROR - 2026-07-03 21:42:39 --> Severity: Warning --> Undefined property: stdClass::$iframes /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/settings.php 279
ERROR - 2026-07-03 21:42:39 --> Severity: Warning --> Undefined property: stdClass::$iframes /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/settings.php 279
ERROR - 2026-07-03 21:42:42 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:42:53 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:43:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:43:01 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:43:03 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:43:04 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:43:43 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:45:20 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:53:41 --> Severity: Warning --> Trying to access array offset on int /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:53:44 --> Severity: Warning --> Trying to access array offset on null /home/u904440099/domains/recetarfacil.com/public_html/application/models/Appointments_model.php 148
ERROR - 2026-07-03 21:54:13 --> Severity: Warning --> Attempt to read property "nombre" on null /home/u904440099/domains/recetarfacil.com/public_html/application/views/backend/super_admin/patients/patient_profile.php 194
ERROR - 2026-07-03 22:17:39 --> 404 Page Not Found: Auth/sign-in
